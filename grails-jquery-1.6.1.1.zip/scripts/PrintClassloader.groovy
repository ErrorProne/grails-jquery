target(default: "Displays what's on the classpath of the various class loaders.") {
    println "Root loader"
    println "-----------"
    printClassLoader rootLoader
    println()

    println "classLoader"
    println "-----------"
    printClassLoader classLoader
    println()
}


void printClassLoader(cl, depth=0) {
    println "    " * depth + "Class: ${cl.class.name}"

    if (cl instanceof URLClassLoader) {
        println "    " * depth + "Paths:"
        cl.URLs.each {
            println "    " * (depth + 1) + it
        }

        if (cl.parent) {
            println()
            printClassLoader cl.parent, depth + 1
        }
    }
}